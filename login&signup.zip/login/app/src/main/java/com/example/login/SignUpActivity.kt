package com.example.login

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SignupActivity : AppCompatActivity() {

    private lateinit var fullName: EditText
    private lateinit var email: EditText
    private lateinit var username: EditText
    private lateinit var password: EditText
    private lateinit var confirmPassword: EditText
    private lateinit var signupButton: Button
    private lateinit var loginLink: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        fullName = findViewById(R.id.fullName)
        email = findViewById(R.id.email)
        username = findViewById(R.id.username)
        password = findViewById(R.id.password)
        confirmPassword = findViewById(R.id.confirmPassword)
        signupButton = findViewById(R.id.signupButton)
        loginLink = findViewById(R.id.loginLink)

        signupButton.setOnClickListener {
            if (validateInput()) {
                // Handle successful signup logic here (e.g., save user data, navigate to another activity, etc.)
                Toast.makeText(this, "Signup successful", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish()
            }
        }

        loginLink.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun validateInput(): Boolean {
        val name = fullName.text.toString().trim()
        val emailStr = email.text.toString().trim()
        val user = username.text.toString().trim()
        val pass = password.text.toString().trim()
        val confirmPass = confirmPassword.text.toString().trim()

        if (name.isEmpty() || emailStr.isEmpty() || user.isEmpty() || pass.isEmpty() || confirmPass.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            return false
        }

        if (!isValidEmail(emailStr)) {
            email.error = "Invalid email format"
            return false
        }

        if (!isValidPassword(pass)) {
            password.error = "Password must contain at least one uppercase letter, one special character, and one number"
            return false
        }

        if (pass != confirmPass) {
            confirmPassword.error = "Passwords do not match"
            return false
        }

        return true
    }

    private fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun isValidPassword(password: String): Boolean {
        val passwordPattern = "^(?=.*[A-Z])(?=.*[!@#\$%^&*()\\-_=+{};:,<.>])(?=.*\\d).{8,}\$"
        return password.matches(passwordPattern.toRegex())
    }
}
